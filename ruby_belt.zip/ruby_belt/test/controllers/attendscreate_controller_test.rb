require 'test_helper'

class AttendscreateControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
