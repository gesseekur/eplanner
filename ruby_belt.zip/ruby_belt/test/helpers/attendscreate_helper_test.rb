require 'test_helper'

class AttendscreateHelperTest < ActionView::TestCase
end
